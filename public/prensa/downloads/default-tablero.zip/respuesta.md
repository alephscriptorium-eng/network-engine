_Sin sesión asociada — pack de loadout._
