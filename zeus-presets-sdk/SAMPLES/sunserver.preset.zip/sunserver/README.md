# SunServer

> Artefacto simulador del sistema solar - Sun

- **Category:** analysis
- **Items:** 5 (2 tools, 2 resources, 1 prompts)

## Prompt

```
En relación a los elementos del sistema solar...
```

## Items

| Server | Type | Name |
|--------|------|------|
| sun | tool | get_position |
| sun | tool | get_rotation |
| sun | resource | server-card |
| sun | resource | body-info |
| sun | prompt | report-status |